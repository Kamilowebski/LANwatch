LANwatch – pakiet ikon PWA

Struktura: skopiuj do katalogu głównego strony:
  /icons/*            – ikony PNG/SVG
  /favicon.ico
  /manifest.webmanifest

Do <head>:
  <link rel="manifest" href="/manifest.webmanifest">
  <link rel="icon" href="/favicon.ico" sizes="any">
  <link rel="icon" href="/icons/icon.svg" type="image/svg+xml">
  <link rel="apple-touch-icon" href="/icons/apple-touch-icon.png">
  <meta name="theme-color" content="#f4f7f9">

Uwaga: jeśli serwer nie zna typu .webmanifest, ustaw
Content-Type: application/manifest+json.
